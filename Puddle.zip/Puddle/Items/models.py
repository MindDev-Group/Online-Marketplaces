from django.contrib.auth.models import User
from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=255)

    class Meta:
        ordering = ('name',)
        verbose_name_plural = 'دسته ها'

    def __str__(self):
        return self.name

class Item(models.Model):
    category = models.ForeignKey(Category, related_name='items', on_delete=models.CASCADE, verbose_name='دسته ها')
    name = models.CharField(max_length=255, verbose_name='نام')
    description = models.TextField(blank=True, null=True, verbose_name='توضیحات')
    price = models.IntegerField(verbose_name='قیمت')
    image = models.ImageField(upload_to='Items_Images', blank=True, null=True, verbose_name='عکس')
    is_sold = models.BooleanField(default=False, verbose_name='فروخته شده')
    created_by = models.ForeignKey(User, related_name='items', on_delete=models.CASCADE, verbose_name='سازنده')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='زمان ساخت')

    def __str__(self):
        return self.name