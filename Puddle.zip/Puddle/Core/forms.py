from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User

class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'placeholder': 'نام کاربری',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))

    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'رمز عبور',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))

class SignUpForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('first_name','last_name', 'username', 'email', 'password1', 'password2')

    first_name = forms.CharField(widget=forms.TextInput(attrs={
        'placeholder': 'نام',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))

    last_name = forms.CharField(widget=forms.TextInput(attrs={
        'placeholder': 'نام خانوادگی',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))

    username = forms.CharField(widget=forms.TextInput(attrs={
        'placeholder': 'نام کاربری',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))

    email = forms.CharField(widget=forms.EmailInput(attrs={
        'placeholder': 'ایمیل',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))

    password1 = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'رمز عبور',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))

    password2 = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'تکرار رمز عبور',
        'class': 'w-full py-4 px-6 rounded-xl',
    }))